#include<stdbool.h>
#include<time.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
#include"dictionary.h"


#define INPUT_WORD_SIZE (100)

// this function is used to take inputs from the user
char *receiveInput(char *s){
    scanf("%99s", s);
    return s;
}

// this function is used to validate the user's input
bool isValidWord(char *word){
	int len = strlen(word);
	int i;

	for(i = 0; i < len; i++){
		if((int)word[i] < 97 || (int)word[i] > 122){
			return false;
		}
	} 
	return true;
}

int main(){
	TrieNode t;
	int i;
    int numWords;

	char word[INPUT_WORD_SIZE];
	char input[INPUT_WORD_SIZE];
	
	// setting the main root as 'not a word'
	t.isEndOfWord = 0;


//-----------------------------------------------------------------------------

    node* temp=load();
    int ch;
    char word_input[50];
    char meaning[200];
    //----------------------------
    for(i = 0; i < 26; i++){
        t.children[i] = NULL;
    } 

    // opening resource file to populate the trie
    FILE *fp = fopen("resources/dictionary.txt", "r");
    if(fp == 0){
        fprintf(stderr, "Error while opening dictionary file");
        exit(1);
    }

    // populating the trie by taking inputs from the file line by line
    while(!feof (fp)){
        fscanf(fp, "%s", word);
        insert(&t, word);
    }

    fclose(fp);

//------------------------------------------------------------

    while(1){
        printf("\n");
        printf("----------------------------");
        printf("\n\n");
        printf("  Menu :  ");
        printf("\n");
        printf("\n\t1.View\n\t2.Add\n\t3.Search\n\t4.Delete\n\t5.Prefix Search\n\t6.Exit\n");
        printf("\n");
        printf("----------------------------");
        printf("\n");
        printf("\nEnter your choice : ");
        scanf("%d", &ch);

        switch(ch){
            case 6: printf("Unloading dictionary");
                    unload(temp);
                    exit(0);
                break;

            case 1: view();
                break;

            case 2: add(temp);
                break;

            case 3: printf("Enter the word:\n");
                    scanf("%s", word_input);

                    
                    for(int i=0;i<1000;i++);

                    if(searching(temp, word_input)){
                        strcpy(meaning, searching(temp,word_input));
                        printf("Meaning:%s\n", meaning);
                    }
                    else printf("Word not found\n");
                    

                break;

            case 4: printf("Enter the word to be deleted:\n");
                    scanf("%s", word_input);
                    deletion(&temp, word_input);
                break;
        

            case 5: printf("Enter keyword: ");
                    receiveInput(input);
                    printf("Enter the maximum number of words to print: ");
                    scanf("%d", &numWords);
                    printf("\n==========================================================\n");
                    printf("\n********************* Possible Words ********************\n");
            
                    if (isValidWord(input)) {
                        clock_t begin = clock();
                        search(&t, input, numWords);
                        clock_t end = clock();
                        double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
                        printf("%f", time_spent);
                    } 
                    else {
                        printf("\n===================== Invalid Input =====================\n");
                    }        
                    default : printf("\nEnter a valid key\n");

            
        
            // printf("==========================================================\n");
        }
    }
    return 0;
}

