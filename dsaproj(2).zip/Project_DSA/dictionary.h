#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#define ALPHABET_SIZE (26)
#define ARRAY_SIZE(a) sizeof(a)/sizeof(a[0])
#define CHAR_TO_INDEX(c) ((int)c - (int)'a')

typedef struct TrieNode{
    struct TrieNode *children[ALPHABET_SIZE];
    bool isEndOfWord;
} TrieNode;

//---------------------------------

typedef struct node{
    struct node* child[26];
    int end_of_word;
    char meaning[100];
}node;


node* load();

//-----------------------------------

void insert(TrieNode* t, char* word_input);
void printLimited(TrieNode *t, char *prefix, int limit, int *numWords);
void print(TrieNode *t, char *prefix);
char *concatenate (char *begin, char letter);

//-------------------------------

void unload(node* dict_remove);
char* searching(node *t, char* key);
void view();
void add(node* t);
int check_children(node* curr);
int deletion(node **curr, char* str);

//-------------------------------


