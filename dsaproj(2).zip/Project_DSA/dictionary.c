#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
#include<time.h>
#include "dictionary.h"

// this function concatenates a letter to agiven set of letters
char *concatenate(char *begin, char letter){
	//allocating memory for the new char set
	char *result = malloc(sizeof (char)* (strlen (begin) + 2));
	int i = 0;
	
	//coping the existing prefix to new memory
	while(begin[i]!='\0'){
		result[i] = begin[i];
		i++;
	} 
	
	//put the letter to end of it
	result[i++] = letter;
	result[i] = '\0';
	
	//returning the reference of concatenated chars
	return result;
}


// this function inserts a new word to the trie creating appropriate nodes
void insert(TrieNode *t, char *word){

	int len = strlen(word);		
	int i;
	
	//populating the new word to the trie
	for(i = 0; i<len; i++){
		TrieNode *current_node = t->children[word[i] % 97];
		
		//creating a new node if a matching node is not present in the trie
		if(current_node == NULL){
			int i;
			current_node = malloc(sizeof(TrieNode));
			current_node->isEndOfWord = 0;
			for(i = 0; i < 26; i++)current_node->children[i] = NULL;
		}
		
		//setting the last node corresponding to the last letter of the word as 'end of a word'
		if(i + 1 == len)
			current_node->isEndOfWord = 1;

		t->children[word[i] % 97] = current_node;
		t = t->children[word[i] % 97];
	}
}


// this function prints all the words from a given prefix root
void print(TrieNode *t, char *prefix){
	//base case returning if the node is null
	if(t == NULL) 
		return;
	
	//start printing if 'is end of word' is set
	if(t->isEndOfWord)
		printf("%s\n", prefix);
	
	
	//recursive calling with the next letter concatinated
	int i;
	for(i = 0; i < 26; i++){
		if(t->children[i] != NULL){
			print(t->children[i], concatenate(prefix, i + 97));
		}
	}
}


//this function finds the subroot of a given prefix and call print
//to print all the words from that subroot
void search(TrieNode *t, char *prefix, int numWords) {
    TrieNode *temp = t;
    int len = strlen(prefix);
    int i;

    // iterating until the subroot
    for (i = 0; i < len; i++) {
        temp = temp->children[prefix[i] % 97];
        if (temp == NULL) {
            // No words with the given prefix exist
            return;
        }
    }
    int count = 0;
    // calling print to print the specified number of words starting from that subroot
    printLimited(temp, prefix, numWords, &count);
}


// This function prints a limited number of words starting from the given node
void printLimited(TrieNode* t, char* prefix, int limit, int* count) {
    // Base case: If the limit is reached or the node is NULL, return
    if (*count >= limit || t == NULL) 
        return;

    // If the current node represents the end of a word, print it
    if (t -> isEndOfWord) {
        printf("%s\n", prefix);
        (*count)++;
    }

    // Recursively traverse all child nodes
    for (int i = 0; i < ALPHABET_SIZE; i++) {
        if (t->children[i] != NULL) {
            // Append the current character to the prefix
            prefix[strlen(prefix)] = (char)(i + 'a');
            prefix[strlen(prefix) + 1] = '\0';

            // Recursively print words from child nodes
            printLimited(t->children[i], prefix, limit, count);

            // Remove the last character from the prefix
            prefix[strlen(prefix) - 1] = '\0';

            // If the limit is reached, stop the traversal
            if (*count >= limit) 
                return;
        }
    }
}


node* load(){
    int i;
    node* root = NULL;
    // Initialize trie for dictionary
    if ((root = malloc (sizeof(node))) == NULL){
        printf ("Out of memory. Dictionary could not be loaded.\n");
    }

    for (i = 0; i < 26; i++)
        root -> child[i] = NULL;
    
    root->end_of_word = 0;
	int index;
	node* temp = root;

    // Dictionary file
    FILE *dict_file = fopen("resources/dictionary1.txt","r+");

    // Dictionary file not opened
    if (dict_file == NULL)
       printf("Error opening dictionary");

    // Store words from Dictionary file
    char word_str[20];
    char meaning[200];


    while((fscanf(dict_file, "%s", word_str)) != EOF){
        fgets(meaning, 200, dict_file);
        int word_len = strlen(word_str);

        for(i = 0; i < word_len; i++){
            // Handle letters of the alphabet
            // Neglect character case
            if (isalpha (word_str[i]))
                index = (int)tolower (word_str[i]) - 'a';

            // Handle error cases
            if (index > 25 || index < 0)
                continue;

            // Insert character from word read from dictionary into Trie
            if (temp -> child[index] == NULL){
                // Create and initialize new next nodes for subsequent letter
                if ((temp -> child[index] = malloc ( sizeof (node))) == NULL)
                    printf ("Out of memory. Dictionary could not be loaded.\n");

                temp = temp -> child[index];
                for (int j = 0; j < 26; j++)
                    temp -> child[j] = NULL;
                    temp -> end_of_word = 0;
            }
            else
                temp = temp -> child[index];
            // Set word as present in dictionary
            if (i == word_len - 1){
                temp -> end_of_word =1;
                strcpy(temp->meaning, meaning);
            }
        } 
        temp = root;
    // If end of file not reached before loop termination and error indicator is not set
    } 
    fclose(dict_file);
    return root;
}


void unload(node* dict_remove){
    node* temp = dict_remove;

    // Recursively freeing allocated memory
    for (int i = 0; i < 26; i++)
        if (temp -> child[i] != NULL)
            unload(temp -> child[i]);

    free (temp);
    temp = NULL;
}


char* searching(node *t, char* key){
    node *temp = t;
    for (int i = 0;key[i]!='\0'; i++){
        int index = (int)tolower(key[i]) - 'a';
        
        if (temp->child[index]==NULL)
            return NULL;

        temp = temp->child[index];
    }

    if((temp->end_of_word==1))
        return temp->meaning;
    else return NULL;
}


void view(){
    FILE *dict_file = fopen("resources/dictionary1.txt","r");
    if (dict_file == NULL)
       printf("Error opening dictionary");
    
    char word_str[20];
    char meaning[200];

    while((fscanf(dict_file, "%s", word_str))!=EOF){
        fgets(meaning, 200, dict_file);
        printf("%s\n", word_str);
    }
    fclose(dict_file);
}


void add(node* t){
    char word1[20];
    char meaning[200];
    char tempmeaning[20];

    printf("Enter the word to add\n");
    scanf("%s", word1);
    printf("Enter the meaning\n");
    scanf("%s", meaning);
    int word_len = strlen(word1);
    int index;
    node* temp=t;
    int i;
    for(i = 0; i < word_len; i++){
        // Handle letters of the alphabet
        // Neglect character case
        if (isalpha (word1[i]))
            index = (int)tolower (word1[i]) - 'a';

        // Handle error cases
        if (index > 25 || index < 0)
            continue;

        // Insert character from word read from dictmptionary into Trie
        if (temp -> child[index] == NULL){
            // Create and initialize new next nodes for subsequent letter
            if ((temp -> child[index] = malloc ( sizeof (node))) == NULL){
                printf ("Out of memory. Dictionary could not be loaded.\n");
            }
            temp = temp -> child[index];
            for (int j = 0; j < 26; j++)
                temp -> child[j] = NULL;
                temp -> end_of_word=0;
        }
        else
            temp = temp -> child[index];
            // Set word as present in dictionary
        if (i == word_len - 1){
            temp -> end_of_word =1;
            strcpy(temp->meaning, meaning);
        }
    }
    FILE *dict_file = fopen("resources/dictionary1.txt","a");

    fprintf(dict_file, "\n%s ", word1);
    fputs(meaning, dict_file);
    fclose(dict_file);
}


// returns 1 if given node has any children
int check_children(node* curr){
	for (int i = 0; i < 26; i++)
		if (curr->child[i])
			return 1;	// child found

	return 0;
}


// Recursive function to delete a string in Trie
int deletion(node **curr, char* str){
	// return if Trie is empty
	if (*curr == NULL)
		return 0;

	// if we have not reached the end of the string
	if (*str){
		// recur for the node corresponding to next character in
		// the string and if it returns 1, delete current node
		// (if it is non-leaf)
		if(*curr != NULL && (*curr)->child[*str - 'a'] != NULL && deletion(&((*curr)->child[*str - 'a']), str + 1) && (*curr)->end_of_word == 0){
			if (!check_children(*curr)){
				free(*curr);
				(*curr) = NULL;
				return 1;
			}
			else 
				return 0;
		}
	}

	// if we have reached the end of the string
	if(*str == '\0' && (*curr)->end_of_word){
		// if current node is a leaf node and don't have any children
		if (!check_children(*curr)){
			free(*curr); // delete current node
			(*curr) = NULL;
			return 1; // delete non-leaf parent nodes
		}

		// if current node is a leaf node and have children
		else{
			// mark current node as non-leaf node (DON'T DELETE IT)
			(*curr)->end_of_word = 0;
			return 0;	   // don't delete its parent nodes
		}
	}

	return 0;
}

